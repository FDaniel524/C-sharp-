﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tabla_periodica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hidrogeno (H)");
            
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Litio");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Berilio");
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sodio");
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Potasio");
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rubidio");
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cesio");
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Francio");
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Magnesio");
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Calcio");
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Estroncio");
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bario");
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Radio");
        }

        private void pictureBox76_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Escandio");
        }

        private void pictureBox75_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ytrio");
        }

        private void pictureBox18_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Titanio");
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Circonio");
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hafnio");
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rutherfordio");
        }

        private void pictureBox22_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Vanadio");
        }

        private void pictureBox21_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Niobio");
        }

        private void pictureBox20_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tántalo");
        }

        private void pictureBox19_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Dubnio");
        }

        private void pictureBox26_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cromo");
        }

        private void pictureBox25_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Molibdeno");
        }

        private void pictureBox24_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Wolframio");
        }

        private void pictureBox23_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Seaborgio");
        }

        private void pictureBox30_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Manganeso");
        }

        private void pictureBox29_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tecnecio");
        }

        private void pictureBox28_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Renio");
        }

        private void pictureBox27_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bohrio");
        }

        private void pictureBox74_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hierro");
        }

        private void pictureBox73_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rutenio");
        }

        private void pictureBox72_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Osmio");
        }

        private void pictureBox71_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hassio");
        }

        private void pictureBox42_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cobalto");
        }

        private void pictureBox41_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rodio");
        }

        private void pictureBox40_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Iridio");
        }

        private void pictureBox39_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Neitnerio");
        }

        private void pictureBox46_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Niquel");
        }

        private void pictureBox45_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Paladio");
        }

        private void pictureBox44_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Platino");
        }

        private void pictureBox43_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Darmstadtio");
        }

        private void pictureBox34_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cobre");
        }

        private void pictureBox33_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Plata");
        }

        private void pictureBox32_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Oro");
        }

        private void pictureBox31_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Roentigenio");
        }

        private void pictureBox38_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cinc");
        }

        private void pictureBox37_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cadmio");
        }

        private void pictureBox36_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mercurio");
        }

        private void pictureBox35_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Copernicio");
        }

        private void pictureBox81_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Boro");
        }

        private void pictureBox50_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Aluminio");
        }

        private void pictureBox49_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Galio");
        }

        private void pictureBox48_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Indio");
        }

        private void pictureBox47_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Talio");
        }

        private void pictureBox82_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Carbono");
        }

        private void pictureBox54_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Silicio");
        }

        private void pictureBox53_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Germanio");
        }

        private void pictureBox52_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Estaño");
        }

        private void pictureBox51_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Plomo");
        }

        private void pictureBox79_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Nitrogeno");
        }

        private void pictureBox58_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Fosforo");
        }

        private void pictureBox57_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Arsénico");
        }

        private void pictureBox56_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Antimonio");
        }

        private void pictureBox55_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bismuto");
        }

        private void pictureBox59_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Polonio");
        }

        private void pictureBox60_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Telurio");
        }

        private void pictureBox61_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Selenio");
        }

        private void pictureBox62_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Azufre");
        }

        private void pictureBox80_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Oxigeno");
        }

        private void pictureBox63_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Astato");
        }

        private void pictureBox67_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Radón");
        }

        private void pictureBox64_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Yodo");
        }

        private void pictureBox68_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Xenón");
        }

        private void pictureBox65_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bromo");
        }

        private void pictureBox69_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Kriptón");
        }

        private void pictureBox66_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cloro");
        }

        private void pictureBox70_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Argón");
        }

        private void pictureBox77_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Flúor");
        }

        private void pictureBox78_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Neón");
        }

        private void pictureBox83_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Helio");
        }

        private void firma_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("Firma.exe");
        }
    }
}
