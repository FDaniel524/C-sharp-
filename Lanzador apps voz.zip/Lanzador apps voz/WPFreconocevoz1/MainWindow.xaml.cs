﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Speech.Recognition;

namespace WPFreconocevoz1
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SpeechRecognitionEngine rec1 = new SpeechRecognitionEngine();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Choices comando = new Choices();
            comando.Add(new string[] { "Crom", "Paint", "Bloc de notas"});
            GrammarBuilder gcrea = new GrammarBuilder();
            gcrea.Append(comando);
            Grammar grama1 = new Grammar(gcrea);
            rec1.LoadGrammarAsync(grama1);
            rec1.SetInputToDefaultAudioDevice();
            rec1.SpeechRecognized += rec1_SpeechRecognized;
        }
        private void btnactivar_Click(object sender, RoutedEventArgs e)
        {
            rec1.RecognizeAsync(RecognizeMode.Multiple);
            btndesactivar.IsEnabled = true;
        }
        void rec1_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            switch (e.Result.Text)
            {
                case "Crom":
                    System.Diagnostics.Process.Start("C:/Program Files/Internet Explorer/iexplore.exe");
                    richtB1.AppendText("Abriendo Google Chrome");
                    break;
                case "´Paint":
                    System.Diagnostics.Process.Start(@"c:windows\mspaint.exe");
                    richtB1.AppendText("Abriendo Paint");
                    break;
                case "Bloc de notas":
                    System.Diagnostics.Process.Start(@"c:windows\notepad.exe");
                    richtB1.AppendText("Abriendo Bloc de Notas");
                    break;
            }
        }
        private void btndesactivar_Click(object sender, RoutedEventArgs e)
        {
            rec1.RecognizeAsyncStop();
            btndesactivar.IsEnabled = false;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start("Firma.exe");
        }
    }
}
