﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        int m, n, i, j;
        double[,] mat;
        String[] split;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("Firma.exe");
        }

        private void tamaño_Click(object sender, EventArgs e)
        {
            m = int.Parse(tBm.Text);
            n = int.Parse(tBn.Text);
            dGmat.RowCount = m;
            dGmat.ColumnCount = n;
            mat = new double[m, n];
        }

        private void poner_Click(object sender, EventArgs e)
        {
            String aux = "";
            for (int i = 0; i < m; i++)
            {
                aux = "";
                for (int j = 0; j < n; j++)
                {
                    aux = aux + mat[i, j] + " ";
                }
                lBm.Items.Add(aux);
            }
        }

        private void leer_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < m; i++)
            {
                 for (int j = 0; j < n; j++)
                 {
                     mat[i, j] = double.Parse(dGmat.Rows[i].Cells[j].Value.ToString());
                 }
             }
        }
                
    }
}
