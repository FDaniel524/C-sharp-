﻿namespace WindowsFormsApp6
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tBm = new System.Windows.Forms.TextBox();
            this.tBn = new System.Windows.Forms.TextBox();
            this.tamaño = new System.Windows.Forms.Button();
            this.leer = new System.Windows.Forms.Button();
            this.poner = new System.Windows.Forms.Button();
            this.dGmat = new System.Windows.Forms.DataGridView();
            this.lBm = new System.Windows.Forms.ListBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dGmat)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(34, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "m";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(36, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "n";
            // 
            // tBm
            // 
            this.tBm.Location = new System.Drawing.Point(68, 58);
            this.tBm.Name = "tBm";
            this.tBm.Size = new System.Drawing.Size(100, 20);
            this.tBm.TabIndex = 2;
            // 
            // tBn
            // 
            this.tBn.Location = new System.Drawing.Point(68, 98);
            this.tBn.Name = "tBn";
            this.tBn.Size = new System.Drawing.Size(100, 20);
            this.tBn.TabIndex = 3;
            // 
            // tamaño
            // 
            this.tamaño.Location = new System.Drawing.Point(59, 177);
            this.tamaño.Name = "tamaño";
            this.tamaño.Size = new System.Drawing.Size(75, 23);
            this.tamaño.TabIndex = 4;
            this.tamaño.Text = "Tamaño";
            this.tamaño.UseVisualStyleBackColor = true;
            this.tamaño.Click += new System.EventHandler(this.tamaño_Click);
            // 
            // leer
            // 
            this.leer.Location = new System.Drawing.Point(59, 206);
            this.leer.Name = "leer";
            this.leer.Size = new System.Drawing.Size(75, 23);
            this.leer.TabIndex = 5;
            this.leer.Text = "Leer";
            this.leer.UseVisualStyleBackColor = true;
            this.leer.Click += new System.EventHandler(this.leer_Click);
            // 
            // poner
            // 
            this.poner.Location = new System.Drawing.Point(59, 235);
            this.poner.Name = "poner";
            this.poner.Size = new System.Drawing.Size(75, 23);
            this.poner.TabIndex = 6;
            this.poner.Text = "Poner";
            this.poner.UseVisualStyleBackColor = true;
            this.poner.Click += new System.EventHandler(this.poner_Click);
            // 
            // dGmat
            // 
            this.dGmat.BackgroundColor = System.Drawing.Color.White;
            this.dGmat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGmat.Location = new System.Drawing.Point(208, 49);
            this.dGmat.Name = "dGmat";
            this.dGmat.Size = new System.Drawing.Size(283, 260);
            this.dGmat.TabIndex = 8;
            // 
            // lBm
            // 
            this.lBm.FormattingEnabled = true;
            this.lBm.Location = new System.Drawing.Point(510, 49);
            this.lBm.Name = "lBm";
            this.lBm.Size = new System.Drawing.Size(282, 264);
            this.lBm.TabIndex = 9;
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.Black;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 35);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(174, 108);
            this.listBox1.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(239, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(221, 31);
            this.label3.TabIndex = 11;
            this.label3.Text = "Lectura de Datos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(531, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(249, 31);
            this.label4.TabIndex = 12;
            this.label4.Text = "Impresión de Datos";
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.Color.Black;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(38, 162);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(120, 147);
            this.listBox2.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(59, 264);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Firma";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OliveDrab;
            this.ClientSize = new System.Drawing.Size(807, 334);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lBm);
            this.Controls.Add(this.dGmat);
            this.Controls.Add(this.poner);
            this.Controls.Add(this.leer);
            this.Controls.Add(this.tamaño);
            this.Controls.Add(this.tBn);
            this.Controls.Add(this.tBm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.listBox2);
            this.MaximumSize = new System.Drawing.Size(823, 373);
            this.MinimumSize = new System.Drawing.Size(823, 373);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dGmat)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tBm;
        private System.Windows.Forms.TextBox tBn;
        private System.Windows.Forms.Button tamaño;
        private System.Windows.Forms.Button leer;
        private System.Windows.Forms.Button poner;
        private System.Windows.Forms.DataGridView dGmat;
        private System.Windows.Forms.ListBox lBm;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button button1;
    }
}

