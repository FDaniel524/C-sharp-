﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        private double d1, r1;
        public Form1()
        {
            InitializeComponent();
            tBd1.Text = "0";
        }

        private void Btlog_Click(object sender, EventArgs e)
        {
            d1 = double.Parse(tBd1.Text);
            r1 = Math.Log10(d1);
            lBresult.Items.Add(r1);
        }

        private void Btsen_Click(object sender, EventArgs e)
        {
            d1 = double.Parse(tBd1.Text);
            r1 = Math.Sin(d1);
            lBresult.Items.Add(r1);
        }

        private void Btcos_Click(object sender, EventArgs e)
        {
            d1 = double.Parse(tBd1.Text);
            r1 = Math.Cos(d1);
            lBresult.Items.Add(r1);
        }

        private void Bttan_Click(object sender, EventArgs e)
        {
            d1 = double.Parse(tBd1.Text);
            r1 = Math.Tan(d1);
            lBresult.Items.Add(r1);
        }

        private void Btcot_Click(object sender, EventArgs e)
        {
            d1 = double.Parse(tBd1.Text);
            r1 = Math.Sin(d1);
            r1 = 1 / r1;
            lBresult.Items.Add(r1);
        }

        private void Btsec_Click(object sender, EventArgs e)
        {
            d1 = double.Parse(tBd1.Text);
            r1 = Math.Cos(d1);
            r1 = 1 / r1;
            lBresult.Items.Add(r1);
        }

        private void Btctg_Click(object sender, EventArgs e)
        {
            d1 = double.Parse(tBd1.Text);
            r1 = Math.Tan(r1);
            r1 = 1 / r1;
            lBresult.Items.Add(r1);
        }

        private void Btlogn_Click(object sender, EventArgs e)
        {
            d1 = double.Parse(tBd1.Text);
            r1 = Math.Log(d1);
            lBresult.Items.Add(r1);
        }

        private void Lbpot_Click(object sender, EventArgs e)
        {
            d1 = double.Parse(tBd1.Text);
            r1 = Math.Pow(d1,2);
            lBresult.Items.Add(r1);
        }

        private void Btclear_Click(object sender, EventArgs e)
        {
            lBresult.Items.Clear();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("Firma.exe");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            d1 = double.Parse(tBd1.Text);
            r1 = Math.Exp(d1);
            lBresult.Items.Add(r1);
        }
    }
}
