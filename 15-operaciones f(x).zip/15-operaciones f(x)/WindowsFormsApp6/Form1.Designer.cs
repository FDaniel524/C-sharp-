﻿namespace WindowsFormsApp6
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tBd1 = new System.Windows.Forms.TextBox();
            this.btexp = new System.Windows.Forms.Button();
            this.lBresult = new System.Windows.Forms.ListBox();
            this.Btlog = new System.Windows.Forms.Button();
            this.Btsen = new System.Windows.Forms.Button();
            this.Btcos = new System.Windows.Forms.Button();
            this.Bttan = new System.Windows.Forms.Button();
            this.Btcsc = new System.Windows.Forms.Button();
            this.Btsec = new System.Windows.Forms.Button();
            this.Btctg = new System.Windows.Forms.Button();
            this.Btlogn = new System.Windows.Forms.Button();
            this.Lbpot = new System.Windows.Forms.Button();
            this.Btclear = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Datos";
            // 
            // tBd1
            // 
            this.tBd1.Location = new System.Drawing.Point(53, 12);
            this.tBd1.Multiline = true;
            this.tBd1.Name = "tBd1";
            this.tBd1.Size = new System.Drawing.Size(74, 24);
            this.tBd1.TabIndex = 1;
            // 
            // btexp
            // 
            this.btexp.Location = new System.Drawing.Point(12, 44);
            this.btexp.Name = "btexp";
            this.btexp.Size = new System.Drawing.Size(75, 23);
            this.btexp.TabIndex = 2;
            this.btexp.Text = "Exp";
            this.btexp.UseVisualStyleBackColor = true;
            this.btexp.Click += new System.EventHandler(this.button1_Click);
            // 
            // lBresult
            // 
            this.lBresult.FormattingEnabled = true;
            this.lBresult.Location = new System.Drawing.Point(351, 15);
            this.lBresult.Name = "lBresult";
            this.lBresult.Size = new System.Drawing.Size(143, 121);
            this.lBresult.TabIndex = 3;
            // 
            // Btlog
            // 
            this.Btlog.Location = new System.Drawing.Point(12, 73);
            this.Btlog.Name = "Btlog";
            this.Btlog.Size = new System.Drawing.Size(75, 23);
            this.Btlog.TabIndex = 4;
            this.Btlog.Text = "Log";
            this.Btlog.UseVisualStyleBackColor = true;
            this.Btlog.Click += new System.EventHandler(this.Btlog_Click);
            // 
            // Btsen
            // 
            this.Btsen.Location = new System.Drawing.Point(93, 44);
            this.Btsen.Name = "Btsen";
            this.Btsen.Size = new System.Drawing.Size(75, 23);
            this.Btsen.TabIndex = 5;
            this.Btsen.Text = "Sen(x)";
            this.Btsen.UseVisualStyleBackColor = true;
            this.Btsen.Click += new System.EventHandler(this.Btsen_Click);
            // 
            // Btcos
            // 
            this.Btcos.Location = new System.Drawing.Point(174, 44);
            this.Btcos.Name = "Btcos";
            this.Btcos.Size = new System.Drawing.Size(75, 23);
            this.Btcos.TabIndex = 6;
            this.Btcos.Text = "Cos(x)";
            this.Btcos.UseVisualStyleBackColor = true;
            this.Btcos.Click += new System.EventHandler(this.Btcos_Click);
            // 
            // Bttan
            // 
            this.Bttan.Location = new System.Drawing.Point(255, 44);
            this.Bttan.Name = "Bttan";
            this.Bttan.Size = new System.Drawing.Size(75, 23);
            this.Bttan.TabIndex = 7;
            this.Bttan.Text = "Tan(x)";
            this.Bttan.UseVisualStyleBackColor = true;
            this.Bttan.Click += new System.EventHandler(this.Bttan_Click);
            // 
            // Btcsc
            // 
            this.Btcsc.Location = new System.Drawing.Point(93, 73);
            this.Btcsc.Name = "Btcsc";
            this.Btcsc.Size = new System.Drawing.Size(75, 23);
            this.Btcsc.TabIndex = 8;
            this.Btcsc.Text = "Csc(x)";
            this.Btcsc.UseVisualStyleBackColor = true;
            this.Btcsc.Click += new System.EventHandler(this.Btcot_Click);
            // 
            // Btsec
            // 
            this.Btsec.Location = new System.Drawing.Point(174, 73);
            this.Btsec.Name = "Btsec";
            this.Btsec.Size = new System.Drawing.Size(75, 23);
            this.Btsec.TabIndex = 9;
            this.Btsec.Text = "Sec(x)";
            this.Btsec.UseVisualStyleBackColor = true;
            this.Btsec.Click += new System.EventHandler(this.Btsec_Click);
            // 
            // Btctg
            // 
            this.Btctg.Location = new System.Drawing.Point(255, 73);
            this.Btctg.Name = "Btctg";
            this.Btctg.Size = new System.Drawing.Size(75, 23);
            this.Btctg.TabIndex = 10;
            this.Btctg.Text = "Cot(x)";
            this.Btctg.UseVisualStyleBackColor = true;
            this.Btctg.Click += new System.EventHandler(this.Btctg_Click);
            // 
            // Btlogn
            // 
            this.Btlogn.Location = new System.Drawing.Point(12, 102);
            this.Btlogn.Name = "Btlogn";
            this.Btlogn.Size = new System.Drawing.Size(75, 23);
            this.Btlogn.TabIndex = 11;
            this.Btlogn.Text = "Ln(x)";
            this.Btlogn.UseVisualStyleBackColor = true;
            this.Btlogn.Click += new System.EventHandler(this.Btlogn_Click);
            // 
            // Lbpot
            // 
            this.Lbpot.Location = new System.Drawing.Point(93, 102);
            this.Lbpot.Name = "Lbpot";
            this.Lbpot.Size = new System.Drawing.Size(75, 23);
            this.Lbpot.TabIndex = 12;
            this.Lbpot.Text = "X^2";
            this.Lbpot.UseVisualStyleBackColor = true;
            this.Lbpot.Click += new System.EventHandler(this.Lbpot_Click);
            // 
            // Btclear
            // 
            this.Btclear.Location = new System.Drawing.Point(255, 102);
            this.Btclear.Name = "Btclear";
            this.Btclear.Size = new System.Drawing.Size(75, 23);
            this.Btclear.TabIndex = 13;
            this.Btclear.Text = "C";
            this.Btclear.UseVisualStyleBackColor = true;
            this.Btclear.Click += new System.EventHandler(this.Btclear_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(174, 129);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Firma";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(506, 164);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Btclear);
            this.Controls.Add(this.Lbpot);
            this.Controls.Add(this.Btlogn);
            this.Controls.Add(this.Btctg);
            this.Controls.Add(this.Btsec);
            this.Controls.Add(this.Btcsc);
            this.Controls.Add(this.Bttan);
            this.Controls.Add(this.Btcos);
            this.Controls.Add(this.Btsen);
            this.Controls.Add(this.Btlog);
            this.Controls.Add(this.lBresult);
            this.Controls.Add(this.btexp);
            this.Controls.Add(this.tBd1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tBd1;
        private System.Windows.Forms.Button btexp;
        private System.Windows.Forms.ListBox lBresult;
        private System.Windows.Forms.Button Btlog;
        private System.Windows.Forms.Button Btsen;
        private System.Windows.Forms.Button Btcos;
        private System.Windows.Forms.Button Bttan;
        private System.Windows.Forms.Button Btcsc;
        private System.Windows.Forms.Button Btsec;
        private System.Windows.Forms.Button Btctg;
        private System.Windows.Forms.Button Btlogn;
        private System.Windows.Forms.Button Lbpot;
        private System.Windows.Forms.Button Btclear;
        private System.Windows.Forms.Button button1;
    }
}

